# Spring Boot with AOP

Just an example of API with Spring Boot and Aspect Oriented Programming (AOP)

https://docs.spring.io/spring/docs/current/spring-framework-reference/html/aop.html


#### How to
Build with `$ gradle build`

Run with `$ gradle bootRun`