package com.formento.aop.exception;

public interface ApplicationException {

    ApplicationExceptionMessage buildApplicationExceptionMessage();

}
