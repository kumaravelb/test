package com.formento.aop.validation;

import com.formento.aop.model.Product;

public interface ProductCreationValidator {

    void validate(Product product);

}
